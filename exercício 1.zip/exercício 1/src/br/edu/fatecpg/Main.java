import java.util.ArrayList;
import java.util.List;

class Produto {
    private String nome;
    private String categoria;
    private double preco;

    public Produto(String nome, String categoria, double preco) {
        this.nome = nome;
        this.categoria = categoria;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return String.format("Produto{nome='%s', categoria='%s', preco=%.2f}", nome, categoria, preco);
    }
}

public class Pratica5StreamLambda {
    public static void main(String[] args) {
        // Criando a lista com 5 produtos
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Produto("Smartphone", "eletronico", 1200.00));
        produtos.add(new Produto("Notebook", "eletronico", 3500.00));
        produtos.add(new Produto("Camiseta", "vestuario", 50.00));
        produtos.add(new Produto("Fone de Ouvido", "eletronico", 150.00));
        produtos.add(new Produto("Livro", "papelaria", 30.00));

        System.out.println("Todos os produtos:");
        produtos.forEach(System.out::println);

        // Filtrando produtos da categoria "eletronico"
        List<Produto> produtosEletronicos = produtos.stream()
                .filter(p -> p.getCategoria().equalsIgnoreCase("eletronico"))
                .toList();

        System.out.println("\nProdutos eletrônicos:");
        produtosEletronicos.forEach(System.out::println);

        // Aplicando 10% de desconto em produtos com preço maior que 100 reais
        produtos.stream()
                .filter(p -> p.getPreco() > 100)
                .forEach(p -> p.setPreco(p.getPreco() * 0.9));

        System.out.println("\nProdutos com desconto aplicado (preço > 100):");
        produtos.forEach(System.out::println);

        // Calculando a soma do preço de todos os produtos
        double somaPrecos = produtos.stream()
                .mapToDouble(Produto::getPreco)
                .sum();

        System.out.printf("\nSoma total dos preços: R$ %.2f\n", somaPrecos);
    }
}