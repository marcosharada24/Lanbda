import java.util.*;
import java.util.stream.Collectors;

class Funcionario {
    private String nome;
    private String departamento;
    private double salario;
    private int anosDeServico;

    public Funcionario(String nome, String departamento, double salario, int anosDeServico) {
        this.nome = nome;
        this.departamento = departamento;
        this.salario = salario;
        this.anosDeServico = anosDeServico;
    }

    // Getters
    public String getNome() {
        return nome;
    }

    public String getDepartamento() {
        return departamento;
    }

    public double getSalario() {
        return salario;
    }

    public int getAnosDeServico() {
        return anosDeServico;
    }

    // Setter para salário (necessário para o aumento)
    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return String.format("Funcionario{nome='%s', departamento='%s', salario=%.2f, anosDeServico=%d}",
                nome, departamento, salario, anosDeServico);
    }
}

public class ManipulacaoFuncionarios {
    public static void main(String[] args) {
        // 2. População da lista com pelo menos 8 funcionários em 3 departamentos
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Ana Silva", "TI", 4500.00, 5));
        funcionarios.add(new Funcionario("Carlos Oliveira", "RH", 3200.00, 3));
        funcionarios.add(new Funcionario("Mariana Santos", "Vendas", 2800.00, 2));
        funcionarios.add(new Funcionario("João Pereira", "TI", 5200.00, 12));
        funcionarios.add(new Funcionario("Patricia Lima", "RH", 3800.00, 8));
        funcionarios.add(new Funcionario("Ricardo Alves", "Vendas", 3100.00, 15));
        funcionarios.add(new Funcionario("Fernanda Costa", "TI", 4800.00, 7));
        funcionarios.add(new Funcionario("Lucas Mendes", "Vendas", 2900.00, 1));

        System.out.println("Lista completa de funcionários:");
        funcionarios.forEach(System.out::println);

        // 3. Operações com Streams e Lambdas

        // a) Filtragem: salário superior a R$ 3000
        List<Funcionario> funcionariosSalarioAlto = funcionarios.stream()
                .filter(f -> f.getSalario() > 3000)
                .collect(Collectors.toList());

        System.out.println("\nFuncionários com salário superior a R$ 3000:");
        funcionariosSalarioAlto.forEach(System.out::println);

        // b) Mapeamento: aumento de 5% para quem tem mais de 10 anos de serviço
        funcionarios.stream()
                .filter(f -> f.getAnosDeServico() > 10)
                .forEach(f -> f.setSalario(f.getSalario() * 1.05));

        System.out.println("\nFuncionários após aumento para quem tem mais de 10 anos de serviço:");
        funcionarios.forEach(System.out::println);

        // c) Ordenação: por nome em ordem alfabética
        List<Funcionario> funcionariosOrdenados = funcionarios.stream()
                .sorted(Comparator.comparing(Funcionario::getNome))
                .collect(Collectors.toList());

        System.out.println("\nFuncionários ordenados por nome:");
        funcionariosOrdenados.forEach(System.out::println);

        // d) Redução: total gasto com salários
        double totalSalarios = funcionarios.stream()
                .mapToDouble(Funcionario::getSalario)
                .sum();

        System.out.printf("\nTotal gasto com salários: R$ %.2f\n", totalSalarios);

        // e) Agrupamento: por departamento com média salarial
        Map<String, Double> mediaSalarialPorDepartamento = funcionarios.stream()
                .collect(Collectors.groupingBy(
                        Funcionario::getDepartamento,
                        Collectors.averagingDouble(Funcionario::getSalario)
                ));

        System.out.println("\nMédia salarial por departamento:");
        mediaSalarialPorDepartamento.forEach((departamento, media) ->
                System.out.printf("%s: R$ %.2f\n", departamento, media));
    }
}